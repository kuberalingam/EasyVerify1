package com.example.easyverify;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputLayout;

public class Login extends AppCompatActivity {

    private EditText phn;
    private EditText mpin;
    private String phns,mpins;
    private Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        phn = findViewById(R.id.editText3);
        mpin = findViewById(R.id.editText4);
    }

    public void thiruMalai(View view){
        phns = phn.getText().toString();
        mpins = mpin.getText().toString();

        if(phns.equals("") && mpins.equals("")){
            phn.setError("*Required");
            mpin.setError("*Required");
        }
        else if (phns.equals("") || mpins.equals("")){
            if(phns.equals("")){
                phn.setError("*Enter Phone Number");
            }
            if(mpins.equals("")){
                mpin.setError("*Enter M-Pin");
            }
        } else {
            if(phns.length() == 10 && mpins.length() == 4){
                intent = new Intent(Login.this, Home.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        }
    }
}
